package com.example.matheus.botodepanico;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class PsaudeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.psaude_activity);
    }
    void avanca(View view){
        Intent intent = new Intent(PsaudeActivity.this, FamiliaresActivity.class);
        startActivity(intent);
        finish();

    }
    void retorna(View view){
        Intent intent = new Intent(PsaudeActivity.this,ConfiguracaoActivity.class);
        startActivity(intent);
        finish();
    }
}

