package com.example.matheus.botodepanico;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class FamiliaresActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.familiares_activity);
    }
    void retorna(View view){
        Intent intent = new Intent(FamiliaresActivity.this,ConfiguracaoActivity.class);
        startActivity(intent);
        finish();
    }
}
