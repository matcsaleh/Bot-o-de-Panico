package com.example.matheus.botodepanico;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;

public class ConfiguracaoActivity extends AppCompatActivity{

    CheckBox checkPlanoSaude;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configuracao_activity);
        checkPlanoSaude = findViewById(R.id.checkPlanoSaude);
    }
    void avanca(View view){

        if(checkPlanoSaude.isChecked()) {
            Intent intent = new Intent(ConfiguracaoActivity.this, PsaudeActivity.class);
            startActivity(intent);
            finish();
        }else{
            Intent intent = new Intent(ConfiguracaoActivity.this, FamiliaresActivity.class);
            startActivity(intent);
            finish();
        }


    }
    void retorna(View view){
        Intent intent = new Intent(ConfiguracaoActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}
