package com.example.matheus.botodepanico.Telas;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.telephony.SmsManager;
import android.widget.Toast;

import com.example.matheus.botodepanico.DBO.BancoController;
import com.example.matheus.botodepanico.DBO.CriaBanco;
import com.example.matheus.botodepanico.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    void configurar(View view){
        Intent intent = new Intent(MainActivity.this, ConfiguracaoActivity.class);
        startActivity(intent);
        finish();

    }

    void btnSos(View v){
       /* BancoController crud = new BancoController(getBaseContext());
        Cursor cursor = crud.carregaDadoById(Integer.parseInt("1"));

        String numero = cursor.getString(cursor.getColumnIndexOrThrow(CriaBanco.TELEFONE_CONTATO));
        String numero1 = cursor.getString(cursor.getColumnIndexOrThrow(CriaBanco.TELEFONE_CONTATO_DOIS));*/
        String numero = "984842270";
        String numero1 = "984144447";
        String mensagem = "Estou em perigo";

        try{
            SmsManager sms = SmsManager.getDefault();
            SmsManager sms1 = SmsManager.getDefault();
            sms.sendTextMessage(numero, null, mensagem , null, null);
            sms1.sendTextMessage(numero1, null, mensagem , null, null);
            Toast.makeText(MainActivity.this,"Mensagem Enviada", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(MainActivity.this,"Ocorreu um erro ao enviar", Toast.LENGTH_SHORT).show();
        }
    }

    void btnVisualiza(View view){
        Intent intent = new Intent(MainActivity.this, FichaMedicaActivity.class);
        startActivity(intent);
        finish();
    }
}
