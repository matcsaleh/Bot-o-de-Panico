package com.example.matheus.botodepanico.Classes;

public class Familiares {
    private String nomeFamiliar;
    private String nomeFamiliar2;
    private String telefone;
    private String telefone2;
    private String parentesco;
    private String parentesco2;

    public Familiares(String nomeFamiliar,String nomeFamiliar2,String telefone,String telefone2,String parentesco,String parentesco2){
        this.nomeFamiliar = nomeFamiliar;
        this.nomeFamiliar2 = nomeFamiliar2;
        this.telefone = telefone;
        this.telefone2 = telefone2;
        this.parentesco = parentesco;
        this.parentesco2 = parentesco2;


    }

    public String getNomeFamiliar() {
        return nomeFamiliar;
    }

    public void setNomeFamiliar(String nomeFamiliar) {
        this.nomeFamiliar = nomeFamiliar;
    }

    public String getNomeFamiliar2() {
        return nomeFamiliar2;
    }

    public void setNomeFamiliar2(String nomeFamiliar2) {
        this.nomeFamiliar2 = nomeFamiliar2;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getTelefone2() {
        return telefone2;
    }

    public void setTelefone2(String telefone2) {
        this.telefone2 = telefone2;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public String getParentesco2() {
        return parentesco2;
    }

    public void setParentesco2(String parentesco2) {
        this.parentesco2 = parentesco2;
    }
}
