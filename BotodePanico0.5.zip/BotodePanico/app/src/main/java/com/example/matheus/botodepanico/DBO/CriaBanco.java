package com.example.matheus.botodepanico.DBO;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class CriaBanco extends SQLiteOpenHelper {
    protected static final String NOME_BANCO = "banco.db";
    protected static final String TABELA_DADOSPESSOAIS = "dadosPessoais";
    protected static final String TABELA_DADOSMEDICOS = "dadosMedicos";
    protected static final String TABELA_DADOSCONTATOS = "dadosContatos";
    protected static final String TABELA_PLANOSAUDE = "dadosPlano";
    protected static final String ID = "idPessoa";
    public    static final String NOME_PESSOA = "nomePessoa";
    protected static final String DATA_NASCIMENTO = "dtNascimento";
    protected static final String CNS = "CNS";
    protected static final String TIPO_SANGUINEO = "tipoSanguineo";
    protected static final String SEXO = "sexo";
    protected static final String ALTURA = "altura";
    protected static final String ALERGIA = "alergia";
    protected static final String NOME_CONTATO = "nomeContato";
    protected static final String NOME_CONTATO_DOIS = "nomeContatoDois";
    public static final String TELEFONE_CONTATO = "telefoneContato";
    public static final String TELEFONE_CONTATO_DOIS = "telefoneContatoDois";
    protected static final String PARENTESCO = "parentesco";
    protected static final String PARENTESCO_DOIS = "parentescoDois";
    protected static final String NOME_PlANO = "nomePlano";
    protected static final String NUMERO_PLANO = "numPlano";
    protected static final String TELEFONE_PLANO = "telefonePlano";
    protected static final String DOENCA = "doenca";
    protected static final String MEDICAMENTO = "medicamento";
    protected static final String MEDICAMENTO_DOIS = "medicamentoDois";
    protected static final String DOSE_DOIS = "doseDois";
    protected static final String DOSE = "dose";
    protected static final String NOME_MEDICO = "nomeMedico";
    protected static final String ESPECIALIZACAO = "especializacao";
    protected static final String TELEFONE_MEDICO = "telefoneMedico";
    protected static final String CRM = "CRM";
    protected static final int VERSAO = 1;

    public CriaBanco(Context context){
        super(context, NOME_BANCO,null,VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql_pessoais = "CREATE TABLE "+TABELA_DADOSPESSOAIS+"("
                + ID + " integer primary key,"
                + NOME_PESSOA + " text,"
                + DATA_NASCIMENTO + " text,"
                + CNS + " text,"
                + TIPO_SANGUINEO + " text,"
                + SEXO + " text,"
                + ALTURA + " text,"
                + ALERGIA + " text,"
                + DOENCA + " text,"
                + MEDICAMENTO + " text,"
                + MEDICAMENTO_DOIS + "text,"
                + DOSE + " text,"
                + DOSE_DOIS + "text"
                +")";

        String sql_medicos = "CREATE TABLE "+TABELA_DADOSMEDICOS+"("
                + NOME_MEDICO + " text,"
                + ESPECIALIZACAO + " text,"
                + TELEFONE_MEDICO + " text,"
                + CRM + "text"
                +")";


        String sql_plano = "CREATE TABLE "+TABELA_PLANOSAUDE+"("
                + NOME_PlANO + " text,"
                + NUMERO_PLANO + " text,"
                + TELEFONE_PLANO + " text"
                +")";


        String sql_contatos = "CREATE TABLE "+TABELA_DADOSCONTATOS+"("
                + NOME_CONTATO + " text,"
                + NOME_CONTATO_DOIS + " text,"
                + TELEFONE_CONTATO + " text,"
                + TELEFONE_CONTATO_DOIS + "text,"
                + PARENTESCO + " text,"
                + PARENTESCO_DOIS + " text"
                +")";

        db.execSQL(sql_pessoais);
        db.execSQL(sql_medicos);
        db.execSQL(sql_plano);
        db.execSQL(sql_contatos);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_DADOSCONTATOS );
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_DADOSMEDICOS );
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_DADOSPESSOAIS);
        db.execSQL("DROP TABLE IF EXISTS " + TABELA_PLANOSAUDE);
        onCreate(db);
    }
}
