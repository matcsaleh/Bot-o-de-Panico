package com.example.matheus.botodepanico.Telas;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

import com.example.matheus.botodepanico.R;

public class PsaudeActivity extends AppCompatActivity {
    EditText editNomePlano;
    EditText editNumeroCartao;
    EditText editTelefonePlano;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.psaude_activity);
        editNomePlano = findViewById(R.id.editNomePlano);
        editNumeroCartao = findViewById(R.id.editNumeroCartao);
        editTelefonePlano = findViewById(R.id.editTelefonePlano);
    }
    void avanca(View view){
        Intent intent = new Intent(PsaudeActivity.this, FamiliaresActivity.class);
        Bundle dados  = getIntent().getExtras();
        dados.putString("numPlano",editTelefonePlano.getText().toString());
        dados.putString("contatoPlano",editTelefonePlano.getText().toString());
        dados.putString("plano",editNomePlano.getText().toString());

        intent.putExtra("dados",dados);
        startActivity(intent);
        finish();

    }
    void retorna(View view){
        Intent intent = new Intent(PsaudeActivity.this, ConfiguracaoActivity.class);
        startActivity(intent);
        finish();
    }
}

