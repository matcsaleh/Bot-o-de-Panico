package com.example.matheus.botodepanico.DBO;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class CriaBanco extends SQLiteOpenHelper {
    protected static final String NOME_BANCO = "banco.db";
    protected static final String TABELA = "dados";
    protected static final String ID = "_id";
    protected static final String NOME = "nome";
    protected static final String DATA_NASCIMENTO = "dtNasc";
    protected static final String CARTAO_SUS = "cartaoSus";
    protected static final String TIPO_SANGUE = "tipoSang";
    protected static final String SEXO = "sexo";
    protected static final String ALTURA = "altura";
    protected static final String FAMILIAR1 = "familiar1";
    public static final String CELULAR1 = "celular1";
    protected static final String PARENTESCO1 = "parentesco1";
    protected static final String FAMILIAR2 = "familiar2";
    public static final String CELULAR2 = "celular2";
    protected static final String PARENTESCO2 = "parentesco2";
    protected static final String PLANO = "plano";
    protected static final String NUMERO_PLANO = "numPlano";
    protected static final String CONTATO_PLANO = "contatoPlano";
    protected static final String ALERGIAS = "alergias";
    protected static final String DOENCAS = "doencas";
    protected static final String REMEDIO = "remedio";
    protected static final String DOSE = "dose";
    protected static final String PERIODOCIDADE = "periodicidade";
    protected static final String MEDICO = "medico";
    protected static final String ESPECIALIDADE_MEDICO = "especMedcio";
    protected static final String TELEFONE_MEDICO = "telefoneMedico";
    protected static final String CRM = "crm";
    protected static final String INFO = "info";

    protected static final int VERSAO = 2;

    public CriaBanco(Context context){
        super(context, NOME_BANCO,null,VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE "+TABELA+"("
                + ID + " integer primary key,"
                + NOME + " text,"
                + DATA_NASCIMENTO + " text,"
                + CARTAO_SUS + " text,"
                + TIPO_SANGUE + " text,"
                + SEXO + " text,"
                + ALTURA + " text,"
                + FAMILIAR1 + " text,"
                + CELULAR1 + " text,"
                + PARENTESCO1 + " text,"
                + FAMILIAR2 + " text,"
                + CELULAR2 + " text,"
                + PARENTESCO2+ " text,"
                + PLANO + " text,"
                + NUMERO_PLANO + " text,"
                + CONTATO_PLANO + " text,"
                + ALERGIAS + " text,"
                + DOENCAS + " text,"
                + REMEDIO + " text,"
                + DOSE + " text,"
                + PERIODOCIDADE + " text,"
                + MEDICO + " text,"
                + ESPECIALIDADE_MEDICO + " text,"
                + TELEFONE_MEDICO + " text,"
                + CRM + " text,"
                + INFO + " text"
                +")";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABELA);
        onCreate(db);
    }
}
