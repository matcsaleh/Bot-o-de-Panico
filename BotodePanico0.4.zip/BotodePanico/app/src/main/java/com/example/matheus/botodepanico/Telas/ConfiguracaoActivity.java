package com.example.matheus.botodepanico.Telas;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.matheus.botodepanico.DBO.BancoController;
import com.example.matheus.botodepanico.MaskEditUtil;
import com.example.matheus.botodepanico.R;

public class ConfiguracaoActivity extends AppCompatActivity {

    CheckBox checkPlanoSaude;
    EditText nomePessoa;
    EditText nascimento;
    EditText cartaoSus;
    EditText altura;

    Spinner spTipoSanguineo;
      /*Spinner spSexo;

    EditText alergia;
    EditText doencaCronica;

    EditText medicamentoUm;
    EditText medicamentoDois;
    EditText doseUm;
    EditText doseDois;
    */




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configuracao_activity);

        ////////////Associação com os /Id's

        checkPlanoSaude = findViewById(R.id.checkPlanoSaude);
        nomePessoa = findViewById(R.id.nomePessoa);
        nascimento = findViewById(R.id.nascimento);
        cartaoSus = findViewById(R.id.cartaoSus);
        altura = findViewById(R.id.altura);
        spTipoSanguineo = findViewById(R.id.spTipoSanguineo);


        ///////////Acionamento das Mascaras
        adicionaMascara();

    }
    void avanca(View view){


        salvaNoBanco();
        if(checkPlanoSaude.isChecked()) {
            Intent intent = new Intent(ConfiguracaoActivity.this, PsaudeActivity.class);
            startActivity(intent);
            finish();
        }else{
            Intent intent = new Intent(ConfiguracaoActivity.this, FamiliaresActivity.class);
            startActivity(intent);
            finish();
        }


    }
    void salvaNoBanco(){
        BancoController crud = new BancoController(getBaseContext());
        //EditText nomePessoa = null;


        //String nome = nomePessoa.getText().toString();


        String resultado = crud.insereDado("teste","teste","teste","teste","teste","teste","teste","teste","teste","teste","teste","teste");

        Toast t = Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG);
        t.show();
    }
    void retorna(View view){
        Intent intent = new Intent(ConfiguracaoActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
    void adicionaMascara(){
        nascimento.addTextChangedListener(MaskEditUtil.mask(nascimento,MaskEditUtil.FORMAT_DATE));
        altura.addTextChangedListener(MaskEditUtil.mask(altura,"#.##"));
        cartaoSus.addTextChangedListener(MaskEditUtil.mask(cartaoSus,"#########"));

    }
}
