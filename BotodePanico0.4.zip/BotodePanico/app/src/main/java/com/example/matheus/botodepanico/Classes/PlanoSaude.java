package com.example.matheus.botodepanico.Classes;

public class PlanoSaude {
    private String nomeConvenio;
    private String telefoneConvenio;
    private String numeroCartao;

    public PlanoSaude(String nomeConvenio,String telefoneConvenio,String numeroCartao){
        this.nomeConvenio = nomeConvenio;
        this.telefoneConvenio = telefoneConvenio;
        this.numeroCartao = numeroCartao;

    }

    public String getNomeConvenio() {
        return nomeConvenio;
    }

    public void setNomeConvenio(String nomeConvenio) {
        this.nomeConvenio = nomeConvenio;
    }

    public String getTelefoneConvenio() {
        return telefoneConvenio;
    }

    public void setTelefoneConvenio(String telefoneConvenio) {
        this.telefoneConvenio = telefoneConvenio;
    }

    public String getNumeroCartao() {
        return numeroCartao;
    }

    public void setNumeroCartao(String numeroCartao) {
        this.numeroCartao = numeroCartao;
    }
}
