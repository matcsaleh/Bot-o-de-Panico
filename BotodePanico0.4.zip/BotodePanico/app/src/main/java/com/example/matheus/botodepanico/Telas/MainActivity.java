package com.example.matheus.botodepanico.Telas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.matheus.botodepanico.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    void configurar(View view){
        Intent intent = new Intent(MainActivity.this, ConfiguracaoActivity.class);
        startActivity(intent);
        finish();

    }
    void btnSos(View view){

    }
    void btnVisualiza(View view){
        Intent intent = new Intent(MainActivity.this, VisualizaActivity.class);
        startActivity(intent);
        finish();
    }
}
