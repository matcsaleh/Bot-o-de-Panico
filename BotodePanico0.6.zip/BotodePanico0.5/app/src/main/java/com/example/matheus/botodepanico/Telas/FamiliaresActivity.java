package com.example.matheus.botodepanico.Telas;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.matheus.botodepanico.Classes.Familiares;
import com.example.matheus.botodepanico.DBO.BancoController;
import com.example.matheus.botodepanico.R;

public class FamiliaresActivity extends AppCompatActivity {
    EditText familiar;
    EditText familiar2;
    EditText telefone;
    EditText telefone2;
    EditText parentesco;
    EditText parentesco2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.familiares_activity);
        familiar.findViewById(R.id.txtFamiliar);
        familiar2.findViewById(R.id.txtNome2);
        telefone.findViewById(R.id.txtTelefone);
        telefone2.findViewById(R.id.txtTelefone2);
        parentesco.findViewById(R.id.txtParentesco);
        parentesco2.findViewById(R.id.txtParentesco2);
    }
    void retorna(View view){
        Intent intent = new Intent(FamiliaresActivity.this, ConfiguracaoActivity.class);
        startActivity(intent);
        finish();
    }
    void salvaNoBanco(){
        BancoController crud = new BancoController(getBaseContext());
        Cursor cursor = crud.carregaDadoById(Integer.parseInt("1"));
        Bundle dados  = getIntent().getExtras();
        if(cursor.getCount() == 0){//cadastro ainda não foi realizado
            Toast.makeText(getApplicationContext(), "Não existem informações cadastradas", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(FamiliaresActivity.this,MainActivity.class);
            startActivity(intent);
        }

        String resultado = crud.insereDado(
                dados.getString("nome"),
                dados.getString("nascimento"),
                dados.getString("cartaoSus"),
                dados.getString("tipoSanguineo"),
                dados.getString("sexo"),
                dados.getString("altura"),
                familiar.getText().toString(),
                telefone.getText().toString(),
                parentesco.getText().toString(),
                familiar2.getText().toString(),
                telefone2.getText().toString(),
                parentesco2.getText().toString(),
                dados.getString("plano"),
                dados.getString("numPlano"),
                dados.getString("contatoPlano"),
                dados.getString("alergias"),
                dados.getString("doenca"),
                dados.getString("remedio"),
                dados.getString("dose"),
                dados.getString("periodicidade"),
                dados.getString("medico"),
                dados.getString("especialidade"),
                dados.getString("telefoneMedico"),
                dados.getString("crm"),
                dados.getString("info")

        );

        Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG).show();

    }
}
