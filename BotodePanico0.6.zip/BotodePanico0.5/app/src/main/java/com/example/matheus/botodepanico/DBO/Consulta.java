package com.example.matheus.botodepanico.DBO;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.matheus.botodepanico.Telas.MainActivity;

import org.w3c.dom.Text;


public class Consulta extends Activity {
   /* private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);

        Button btVoltar = (Button) findViewById(R.id.btVoltar);

        TextView txtNome = (TextView) findViewById(R.id.txtNome);
        TextView txtEmail = (TextView) findViewById(R.id.txtEmail);

        BancoController crud = new BancoController(getBaseContext());
        Cursor cursor = crud.carregaDadoById(Integer.parseInt("1"));

        if(cursor.getCount() == 0){//cadastro ainda não foi realizado
            Toast.makeText(getApplicationContext(), "Não existem informações cadastradas", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Consulta.this,MainActivity.class);
            startActivity(intent);
        }else {
            txtNome.setText(cursor.getString(cursor.getColumnIndexOrThrow(CriaBanco.NOME)));
            txtEmail.setText(cursor.getString(cursor.getColumnIndexOrThrow(CriaBanco.EMAIL)));

            btVoltar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Consulta.this, MainActivity.class);
                    startActivity(intent);
                }
            });
        }
    }*/
}
