package com.example.matheus.botodepanico.Classes;

public class Medico {
    private  String nomeMedico;
    private String crm;
    private String telefone;
    private  String especializacao;

    public Medico(String nomeMedico, String crm, String telefone, String especializacao){
        this.nomeMedico = nomeMedico;
        this.crm = crm;
        this.telefone = telefone;
        this.especializacao = especializacao;

    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEspecializacao() {
        return especializacao;
    }

    public void setEspecializacao(String especializacao) {
        this.especializacao = especializacao;
    }

    public String getNomeMedico() {
        return nomeMedico;
    }

    public void setNomeMedico(String nomeMedico) {
        this.nomeMedico = nomeMedico;
    }
}
