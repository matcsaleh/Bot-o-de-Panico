package com.example.matheus.botodepanico.DBO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;

public class BancoController {

    private SQLiteDatabase db;
    private CriaBanco banco;

    public BancoController(Context context){
        banco = new CriaBanco(context);
    }

    public String insereDado(String nomePessoa, String dtNasc , String cartaoSus, String tipoSang , String sexo
            , String altura , String familiar1 , String celular1, String parentesco1, String familiar2, String celular2 ,
                             String parentesco2, String plano, String numPlano , String contatoPlano , String alergias,
                             String doencas , String remedio , String dose, String periodicidade, String medico ,
                             String especMedcio , String telefoneMedico , String crm , String info){
        ContentValues valores;
        long resultado;

       db = banco.getWritableDatabase();
       valores = new ContentValues();
       valores.put(banco.ID, 1);
       /*
       Nota: sempre haverá somente um cadastro se setar o valor de ID
       e o campo ID não for campo do tipo auto-increment.
       Para cadastrar várias linhas na tabela, é preciso configurar
       o campo ID como auto-increment (CriaBanco.java) e não setar
       o valor do ID neste método
       */
       valores.put(banco.NOME, nomePessoa);
       valores.put(banco.DATA_NASCIMENTO, dtNasc);
       valores.put(banco.CARTAO_SUS, cartaoSus);
       valores.put(banco.TIPO_SANGUE, tipoSang);
       valores.put(banco.SEXO, sexo);
       valores.put(banco.ALTURA, altura);
       valores.put(banco.FAMILIAR1, familiar1);
       valores.put(banco.CELULAR1, celular1);
       valores.put(banco.PARENTESCO1, parentesco1);
       valores.put(banco.FAMILIAR2, familiar2);
       valores.put(banco.CELULAR2, celular2);
       valores.put(banco.PARENTESCO2, parentesco2);
       valores.put(banco.PLANO, plano);
       valores.put(banco.NUMERO_PLANO, numPlano);
       valores.put(banco.CONTATO_PLANO , contatoPlano);
       valores.put(banco.ALERGIAS , alergias);
       valores.put(banco.DOENCAS, doencas);
       valores.put(banco.REMEDIO, remedio);
       valores.put(banco.DOSE, dose);
       valores.put(banco.PERIODOCIDADE, periodicidade);
       valores.put(banco.MEDICO, medico);
       valores.put(banco.ESPECIALIDADE_MEDICO, especMedcio);
       valores.put(banco.TELEFONE_MEDICO, telefoneMedico);
       valores.put(banco.CRM, crm);
       valores.put(banco.INFO, info);

       resultado = db.insertOrThrow(banco.TABELA, null, valores);
       db.close();

       if (resultado ==-1)
           return "Erro ao inserir registro";
       else
           return "Registro Inserido com sucesso";
    }

    /*public Cursor carregaDados(){
            Cursor cursor;
            String[] campos =  {banco.ID,banco.NOME,banco.DATA_NASCIMENTO};
            db = banco.getReadableDatabase();
            cursor = db.query(banco.TABELA, campos, null, null, null, null, null, null);

            if(cursor!=null){
                cursor.moveToFirst();
            }

            return cursor;
    }*/


    public Cursor carregaDadoById(int id){
        Cursor cursor;
        String[] campos =  {banco.ID,banco.NOME,banco.DATA_NASCIMENTO};
        String where = CriaBanco.ID + "=" + id;
        db = banco.getReadableDatabase();
        cursor = db.query(CriaBanco.TABELA,campos,where, null, null, null, null, null);

        if(cursor!=null){
            cursor.moveToFirst();
        }else{
            return null;
        }

        return cursor;
    }
/*
    public void alteraRegistro(int id, String nome, String email){
        ContentValues valores;
        String where;

        db = banco.getWritableDatabase();

        where = CriaBanco.ID + "=" + id;

        valores = new ContentValues();
        valores.put(banco.NOME, nome);
        valores.put(banco.EMAIL, email);

        db.update(CriaBanco.TABELA,valores,where,null);
    }

    public void deletaRegistro(int id){
        String where = CriaBanco.ID + "=" + id;
        db = banco.getWritableDatabase();
        db.delete(CriaBanco.TABELA,where,null);
    }
    */
}
