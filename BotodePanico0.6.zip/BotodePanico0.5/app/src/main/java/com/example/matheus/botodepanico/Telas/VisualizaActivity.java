package com.example.matheus.botodepanico.Telas;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.matheus.botodepanico.DBO.BancoController;
import com.example.matheus.botodepanico.DBO.CriaBanco;
import com.example.matheus.botodepanico.R;

public class VisualizaActivity extends AppCompatActivity {
    //Toast t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.visualiza_activity);

        ListView lista = findViewById(R.id.listaExibir);

        BancoController crud = new BancoController(getBaseContext());
       /* Cursor cursor = crud.carregaDados();


        if (cursor.getCount() == 0) {//cadastro ainda não foi realizado
            Toast t = Toast.makeText(getApplicationContext(), "Não existem informações cadastradas", Toast.LENGTH_LONG);
            t.show();
            Intent intent = new Intent(VisualizaActivity.this, MainActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "Deu certo", Toast.LENGTH_LONG).show();
        }
        */
    }
}




