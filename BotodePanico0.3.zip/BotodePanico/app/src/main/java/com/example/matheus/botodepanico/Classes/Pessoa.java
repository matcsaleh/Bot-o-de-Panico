package com.example.matheus.botodepanico.Classes;

public class Pessoa {

    private String nomePessoa;
    private String dataNascimento;
    private String cns;
    private String tipoSanguineo;
    private String sexo;
    private String altura;
    private String nomeMedicamento;
    private String nomeMedicamento2;
    private String dose;
    private String dose2;

    Pessoa(String nomePessoa,String dataNascimento,String cns, String tipoSanguineo,
           String sexo,String altura,String nomeMedicamento,String nomeMedicamento2, String dose,String dose2,Medico medico){
        this.setNomePessoa(nomePessoa);
        this.setDataNascimento(dataNascimento);
        this.setCns(cns);
        this.setTipoSanguineo(tipoSanguineo);
        this.setSexo(sexo);
        this.setAltura(altura);
        this.setNomeMedicamento(nomeMedicamento);
        this.setNomeMedicamento2(nomeMedicamento2);
        this.setDose(dose);
        this.setDose2(dose2);
    }

    public String getNomePessoa() {
        return nomePessoa;
    }

    public void setNomePessoa(String nomePessoa) {
        this.nomePessoa = nomePessoa;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCns() {
        return cns;
    }

    public void setCns(String cns) {
        this.cns = cns;
    }

    public String getTipoSanguineo() {
        return tipoSanguineo;
    }

    public void setTipoSanguineo(String tipoSanguineo) {
        this.tipoSanguineo = tipoSanguineo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }

    public String getNomeMedicamento() {
        return nomeMedicamento;
    }

    public void setNomeMedicamento(String nomeMedicamento) {
        this.nomeMedicamento = nomeMedicamento;
    }

    public String getNomeMedicamento2() {
        return nomeMedicamento2;
    }

    public void setNomeMedicamento2(String nomeMedicamento2) {
        this.nomeMedicamento2 = nomeMedicamento2;
    }

    public String getDose() {
        return dose;
    }

    public void setDose(String dose) {
        this.dose = dose;
    }

    public String getDose2() {
        return dose2;
    }

    public void setDose2(String dose2) {
        this.dose2 = dose2;
    }
}
