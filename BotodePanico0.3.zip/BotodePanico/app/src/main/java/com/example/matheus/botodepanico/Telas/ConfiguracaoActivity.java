package com.example.matheus.botodepanico.Telas;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.matheus.botodepanico.MaskEditUtil;
import com.example.matheus.botodepanico.R;

public class ConfiguracaoActivity extends AppCompatActivity {

    CheckBox checkPlanoSaude;
    EditText nomePessoa;
    EditText nascimento;
    EditText cartaoSus;
    EditText altura;
    Spinner tipoSanguineo;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.configuracao_activity);

        ////////////Associação com os /Id's
        checkPlanoSaude = findViewById(R.id.checkPlanoSaude);
        nascimento = findViewById(R.id.nascimento);
        cartaoSus = findViewById(R.id.cartaoSus);
        altura = findViewById(R.id.altura);
        tipoSanguineo = findViewById(R.id.spTipoSanguineo);

        ///////////Acionamento das Mascaras
        adicionaMascara();

    }
    void avanca(View view){

        if(checkPlanoSaude.isChecked()) {
            Intent intent = new Intent(ConfiguracaoActivity.this, PsaudeActivity.class);
            startActivity(intent);
            finish();
        }else{
            Intent intent = new Intent(ConfiguracaoActivity.this, FamiliaresActivity.class);
            startActivity(intent);
            finish();
        }


    }
    void retorna(View view){
        Intent intent = new Intent(ConfiguracaoActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
    void adicionaMascara(){
        nascimento.addTextChangedListener(MaskEditUtil.mask(nascimento,MaskEditUtil.FORMAT_DATE));
        altura.addTextChangedListener(MaskEditUtil.mask(altura,"#.##"));
    }
}
