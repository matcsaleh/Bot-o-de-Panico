package com.example.matheus.botodepanico;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Cadastrar extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        //Setar Atributos
        Button botao = (Button)findViewById(R.id.button);


        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BancoController crud = new BancoController(getBaseContext());
                EditText editNome = (EditText)findViewById(R.id.editNome);
                EditText editEmail = (EditText)findViewById(R.id.editEmail);

                String nome = editNome.getText().toString();
                String email = editEmail.getText().toString();

                String resultado;

                resultado = crud.insereDado(nome,email);

                Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG).show();

                Intent intent = new Intent(Cadastrar.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
